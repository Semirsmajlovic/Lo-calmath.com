<?php
/*
Plugin Name: Elated Woocommerce Checkout Integration
Description: Plugin that adds custom post type to woocommerce checkout
Author: Elated Themes
Version: 1.1.1
*/

include_once 'load.php';
