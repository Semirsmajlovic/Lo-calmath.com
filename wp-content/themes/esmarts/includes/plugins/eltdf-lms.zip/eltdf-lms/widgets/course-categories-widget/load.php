<?php

include_once ELATED_LMS_ABS_PATH . '/widgets/course-categories-widget/functions.php';
include_once ELATED_LMS_ABS_PATH . '/widgets/course-categories-widget/course-categories.php';