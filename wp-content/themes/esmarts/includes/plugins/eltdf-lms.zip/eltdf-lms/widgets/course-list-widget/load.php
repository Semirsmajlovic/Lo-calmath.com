<?php

include_once ELATED_LMS_ABS_PATH . '/widgets/course-list-widget/functions.php';
include_once ELATED_LMS_ABS_PATH . '/widgets/course-list-widget/course-list.php';