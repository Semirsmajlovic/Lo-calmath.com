<span class="eltdf-course-whishlist-wrapper">
	<a href="javascript:void(0)" class="eltdf-course-whishlist" data-course-id="<?php echo get_the_ID(); ?>">
        <i class="lnr <?php echo esc_attr( $wishlist_icon ); ?>"></i>
        <span class="eltdf-course-wishlist-text">
            <?php echo esc_attr( $wishlist_text ); ?>
        </span>
    </a>
</span>
