<div class="eltdf-course-action">
	<?php eltdf_lms_get_buy_form(); ?>
</div>