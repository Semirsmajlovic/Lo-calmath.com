<?php

get_header();

esmarts_elated_get_title();

do_action( 'esmarts_elated_action_before_main_content' );

eltdf_lms_get_single_instructor();

get_footer();