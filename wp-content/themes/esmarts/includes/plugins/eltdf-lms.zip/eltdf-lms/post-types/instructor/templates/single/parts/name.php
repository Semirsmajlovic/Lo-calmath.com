<h4 itemprop="name" class="eltdf-name entry-title">
	<?php the_title(); ?>
</h4>