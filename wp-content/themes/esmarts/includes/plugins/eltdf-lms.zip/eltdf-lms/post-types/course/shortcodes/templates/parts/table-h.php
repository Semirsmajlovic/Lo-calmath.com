<div class="eltdf-ct-headings">
	<div class="eltdf-ct-headings-inner">
		<h4 class="eltdf-ct-course"><?php esc_html_e( "Courses program", "eltdf-lms" ); ?></h4>
		<h4 class="eltdf-ct-category"><?php esc_html_e( "Category", "eltdf-lms" ); ?></h4>
		<h4 class="eltdf-ct-instructor"><?php esc_html_e( "Instructor", "eltdf-lms" ); ?></h4>
		<h4 class="eltdf-ct-price"><?php esc_html_e( "Price", "eltdf-lms" ); ?></h4>
	</div>
	<div class="eltdf-ct-headings-mobile">
		<h4 class="eltdf-ct-lable"><?php esc_html_e( "Courses info", "eltdf-lms" ); ?></h4>
	</div>
</div>