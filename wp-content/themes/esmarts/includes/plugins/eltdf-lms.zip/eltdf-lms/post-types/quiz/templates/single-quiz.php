<?php

get_header();

esmarts_elated_get_title();

eltdf_lms_get_single_quiz();

get_footer();