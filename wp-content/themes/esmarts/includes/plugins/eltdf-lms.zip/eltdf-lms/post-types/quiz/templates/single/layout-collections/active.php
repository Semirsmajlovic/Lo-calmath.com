<div class="eltdf-quiz-active-wrapper">
	<div class="eltdf-quiz-title-wrapper">
		<?php eltdf_lms_get_cpt_single_module_template_part( 'templates/single/parts/title', 'quiz', '', $params ); ?>
	</div>
	<div class="eltdf-quiz-info-top-wrapper">
		<?php eltdf_lms_get_cpt_single_module_template_part( 'templates/single/parts/info-top', 'quiz', 'active', $params ); ?>
	</div>
	<div class="eltdf-quiz-question-wrapper">
		<?php eltdf_lms_get_cpt_single_module_template_part( 'templates/single/layout-collections/default', 'question', '', $params ); ?>
	</div>
</div>