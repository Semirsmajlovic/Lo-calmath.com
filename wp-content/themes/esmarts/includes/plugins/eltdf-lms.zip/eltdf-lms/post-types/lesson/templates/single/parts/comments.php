<?php

if ( esmarts_elated_show_comments() ) {
	comments_template( '', true );
}