<?php

include_once ELATED_LMS_CPT_PATH . '/lesson/lesson-register.php';
include_once ELATED_LMS_CPT_PATH . '/lesson/helper-functions.php';