<?php

if ( ! empty( $courses['selected_courses'] ) ) {
	echo esmarts_elated_execute_shortcode('eltdf_course_list', $courses);
}