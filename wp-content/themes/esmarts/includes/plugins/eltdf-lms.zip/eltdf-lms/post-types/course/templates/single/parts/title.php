<h3 class="eltdf-course-single-title">
	<?php the_title(); ?>
</h3>