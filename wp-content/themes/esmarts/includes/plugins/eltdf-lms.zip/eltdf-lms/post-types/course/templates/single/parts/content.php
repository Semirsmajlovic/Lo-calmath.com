<div class="eltdf-course-content">
	<h4 class="eltdf-course-content-title"><?php esc_html_e( 'About this course', 'eltdf-lms' ) ?></h4>
	<?php the_content(); ?>
</div>