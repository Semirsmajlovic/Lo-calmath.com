<h4 class="eltdf-quiz-single-title">
	<?php the_title(); ?>
</h4>