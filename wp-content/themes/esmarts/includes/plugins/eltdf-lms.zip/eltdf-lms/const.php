<?php

define( 'ELATED_LMS_VERSION', '1.1.5' );
define( 'ELATED_LMS_ABS_PATH', dirname( __FILE__ ) );
define( 'ELATED_LMS_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'ELATED_LMS_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'ELATED_LMS_ASSETS_PATH', ELATED_LMS_ABS_PATH . '/assets' );
define( 'ELATED_LMS_ASSETS_URL_PATH', ELATED_LMS_URL_PATH . 'assets' );
define( 'ELATED_LMS_CPT_PATH', ELATED_LMS_ABS_PATH . '/post-types' );
define( 'ELATED_LMS_CPT_URL_PATH', ELATED_LMS_URL_PATH . 'post-types' );
define( 'ELATED_LMS_SHORTCODES_PATH', ELATED_LMS_ABS_PATH . '/shortcodes' );
define( 'ELATED_LMS_SHORTCODES_URL_PATH', ELATED_LMS_URL_PATH . 'shortcodes' );