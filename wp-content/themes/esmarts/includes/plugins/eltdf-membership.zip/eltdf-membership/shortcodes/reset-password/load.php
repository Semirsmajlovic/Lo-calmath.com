<?php

include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/functions.php';
include_once ELATED_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/reset-password.php';