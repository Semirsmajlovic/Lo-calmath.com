<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/banner-simple/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/banner-simple/banner-simple.php';