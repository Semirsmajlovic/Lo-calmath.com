<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/education-timeline/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/education-timeline/education-timeline-holder.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/education-timeline/education-timeline-item.php';