<div class="eltdf-tml-item-holder">
    <span class="eltdf-tml-item-circle"></span>
    <div class="eltdf-tml-item-content">
        <h6 class="eltdf-tml-item-title"><?php echo esc_html($title);?></h6>
        <p class="eltdf-tml-item-subtitle"><?php echo esc_html($subtitle);?></p>
    </div>
</div>