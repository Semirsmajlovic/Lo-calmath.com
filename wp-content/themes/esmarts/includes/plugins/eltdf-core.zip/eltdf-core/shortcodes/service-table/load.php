<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/service-table/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/service-table/service-table.php';